package com.workmate.backend.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.workmate.backend.dto.evaluation.IntentTestCase;
import com.workmate.backend.dto.evaluation.IntentEvaluationResult;
import com.workmate.backend.dto.response.IntentClassificationResponse;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IntentEvaluationService {

    private final ObjectMapper objectMapper;
    private final ClaudeService claudeService;

    public IntentEvaluationService(
            ObjectMapper objectMapper,
            ClaudeService claudeService) {

        this.objectMapper = objectMapper;
        this.claudeService = claudeService;
    }

    public List<IntentEvaluationResult> evaluate()
            throws Exception {

        List<IntentTestCase> testCases = objectMapper.readValue(
                new ClassPathResource(
                        "evaluation/intent-test-cases.json").getInputStream(),
                new TypeReference<>() {
                });

        return testCases.stream()
                .map(testCase -> {

                    IntentClassificationResponse prediction = claudeService.classifyRequest(
                            testCase.input());

                    boolean correct = prediction.intent() == testCase.expectedIntent();

                    return new IntentEvaluationResult(
                            testCase.id(),
                            testCase.input(),
                            testCase.expectedIntent(),
                            prediction.intent(),
                            correct);
                })
                .toList();
    }
}