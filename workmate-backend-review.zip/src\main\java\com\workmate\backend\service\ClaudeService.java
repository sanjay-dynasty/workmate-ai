package com.workmate.backend.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.workmate.backend.dto.response.ClaudeChatResponse;
import com.workmate.backend.dto.response.IntentClassificationResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@Service
public class ClaudeService {

        private final RestClient claudeRestClient;
        private final String model;

        private final WorkMateSystemPrompt workMateSystemPrompt;
        private final ObjectMapper objectMapper;
        private final SchemaValidationService schemaValidationService;
        private final IntentResponseValidator intentResponseValidator;

        public ClaudeService(
                        RestClient claudeRestClient,
                        @Value("${anthropic.model}") String model,
                        WorkMateSystemPrompt workMateSystemPrompt,
                        ObjectMapper objectMapper,
                        SchemaValidationService schemaValidationService,
                        IntentResponseValidator intentResponseValidator) {

                this.claudeRestClient = claudeRestClient;
                this.model = model;
                this.workMateSystemPrompt = workMateSystemPrompt;
                this.objectMapper = objectMapper;
                this.schemaValidationService = schemaValidationService;
                this.intentResponseValidator = intentResponseValidator;
        }

        // PHASE 0: Basic Claude conversation

        public ClaudeChatResponse chat(String userMessage) {

                Map<String, Object> requestBody = Map.of(
                                "model", model,
                                "max_tokens", 500,
                                "system", workMateSystemPrompt.getSystemPrompt(),
                                "messages", List.of(
                                                Map.of(
                                                                "role", "user",
                                                                "content", userMessage)));

                JsonNode response = claudeRestClient.post()
                                .uri("/v1/messages")
                                .body(requestBody)
                                .retrieve()
                                .body(JsonNode.class);

                if (response == null) {
                        throw new IllegalStateException(
                                        "Empty response received from Claude");
                }

                String answer = response.path("content")
                                .findValue("text")
                                .asText();

                return new ClaudeChatResponse(
                                answer,
                                response.path("model").asText(),
                                response.path("stop_reason").asText());
        }

        // PHASE 1: Prompt experiment

        public String chatWithSystemPrompt(
                        String systemPrompt,
                        String userMessage) {

                Map<String, Object> requestBody = Map.of(
                                "model", model,
                                "max_tokens", 300,
                                "system", systemPrompt,
                                "messages", List.of(
                                                Map.of(
                                                                "role", "user",
                                                                "content", userMessage)));

                JsonNode response = claudeRestClient.post()
                                .uri("/v1/messages")
                                .body(requestBody)
                                .retrieve()
                                .body(JsonNode.class);

                if (response == null) {
                        throw new IllegalStateException(
                                        "Empty Claude response");
                }

                return response.path("content")
                                .findValue("text")
                                .asText();
        }

        // PHASE 1: Generate schema-constrained JSON

        private String generateStructuredResponse(String userMessage) {

                try {

                        JsonNode schema = objectMapper.readTree(
                                        new ClassPathResource(
                                                        "schemas/intent-classification-schema.json").getInputStream());

                        Map<String, Object> requestBody = Map.of(
                                        "model", model,
                                        "max_tokens", 700,
                                        "system", workMateSystemPrompt.getSystemPrompt(),
                                        "messages", List.of(
                                                        Map.of(
                                                                        "role", "user",
                                                                        "content", userMessage)),
                                        "output_config", Map.of(
                                                        "format", Map.of(
                                                                        "type", "json_schema",
                                                                        "schema", schema)));

                        JsonNode response = claudeRestClient.post()
                                        .uri("/v1/messages")
                                        .body(requestBody)
                                        .retrieve()
                                        .body(JsonNode.class);

                        if (response == null) {
                                throw new IllegalStateException(
                                                "Empty response from Claude");
                        }

                        String stopReason = response.path("stop_reason").asText();

                        if (!"end_turn".equals(stopReason)) {
                                throw new IllegalStateException(
                                                "Claude response incomplete. Stop reason: "
                                                                + stopReason);
                        }

                        for (JsonNode block : response.path("content")) {

                                if ("text".equals(block.path("type").asText())) {
                                        return block.path("text").asText();
                                }
                        }

                        throw new IllegalStateException(
                                        "No text content returned by Claude");

                } catch (IOException exception) {

                        throw new IllegalStateException(
                                        "Unable to load JSON schema",
                                        exception);
                }
        }

        // PHASE 1: Validate and deserialize Claude response

        public IntentClassificationResponse classifyRequest(
                        String userMessage) {

                String json = generateStructuredResponse(userMessage);

                schemaValidationService.validate(json);

                try {

                        IntentClassificationResponse result = objectMapper.readValue(
                                        json,
                                        IntentClassificationResponse.class);

                        intentResponseValidator.validate(result);

                        return result;

                } catch (Exception exception) {

                        throw new IllegalStateException(
                                        "Failed to parse Claude classification response",
                                        exception);
                }
        }
}
