package com.workmate.backend.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.networknt.schema.JsonSchema;
import com.networknt.schema.JsonSchemaFactory;
import com.networknt.schema.SpecVersion;
import com.networknt.schema.ValidationMessage;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
public class SchemaValidationService {

    private final ObjectMapper objectMapper;

    private final JsonSchema schema;

    public SchemaValidationService(
            ObjectMapper objectMapper) throws Exception {

        this.objectMapper = objectMapper;

        JsonNode schemaNode = objectMapper.readTree(
                new ClassPathResource(
                        "schemas/intent-classification-schema.json").getInputStream());

        JsonSchemaFactory factory = JsonSchemaFactory.getInstance(
                SpecVersion.VersionFlag.V202012);

        this.schema = factory.getSchema(schemaNode);
    }

    public void validate(String json) {

        try {
            JsonNode jsonNode = objectMapper.readTree(json);

            Set<ValidationMessage> errors = schema.validate(jsonNode);

            if (!errors.isEmpty()) {
                throw new IllegalArgumentException(
                        "Invalid Claude JSON response: " + errors);
            }

        } catch (Exception exception) {

            throw new IllegalArgumentException(
                    "Unable to validate Claude response",
                    exception);
        }
    }
}